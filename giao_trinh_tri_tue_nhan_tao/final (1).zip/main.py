from MazeApp import MazeApp
if __name__ == "__main__":
    mazeApp = MazeApp()